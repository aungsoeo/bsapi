<footer class="footer text-right"> 2019 © <a href="http://www.spagreen.net"> <?php echo $system_name;?></a> |
  Developed by: <a href="http://www.spagreen.net"> BS Admin Team</a> </footer>
